export interface Product {
  id: string;
  name: string;
  vendor: string;
  price: number;
  image: string;
  description: string;
  rating: number;
  reviews: Review[];
  vendorStory: string;
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface SubscriptionBox {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  features: string[];
}

export interface Order {
  id: string;
  date: string;
  items: OrderItem[];
  total: number;
  status: string;
}

export interface OrderItem {
  product: Product;
  quantity: number;
  isFavorite: boolean;
  userRating?: number;
  userReview?: string;
}

export const mockProducts: Product[] = [
  {
    id: '1',
    name: 'Handwoven Ceramic Bowl Set',
    vendor: 'Clay Dreams Studio',
    price: 899,
    image: 'https://images.unsplash.com/photo-1695740639466-7baecca4224d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwcG90dGVyeSUyMGhhbmRtYWRlfGVufDF8fHx8MTc1ODc4MTg2OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Beautiful set of handcrafted ceramic bowls perfect for your dining table. Each piece is unique and made with love by local artisans.',
    rating: 4.8,
    reviews: [
      {
        id: '1',
        userName: 'Priya S.',
        rating: 5,
        comment: 'Absolutely gorgeous bowls! The craftsmanship is amazing.',
        date: '2024-01-15'
      },
      {
        id: '2',
        userName: 'Rajesh K.',
        rating: 4,
        comment: 'Good quality, but delivery took a bit longer than expected.',
        date: '2024-01-10'
      }
    ],
    vendorStory: 'Clay Dreams Studio was founded by Meera Patel in 2018. Starting from her garage, she now employs 15 local artisans and focuses on sustainable pottery practices.'
  },
  {
    id: '2',
    name: 'Handcrafted Wooden Jewelry Box',
    vendor: 'WoodCraft Collective',
    price: 1299,
    image: 'https://images.unsplash.com/photo-1755991699037-73eb5dff62f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b29kZW4lMjBjcmFmdCUyMGFydGlzYW58ZW58MXx8fHwxNzU4Nzg0MTQ4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Exquisite wooden jewelry box with intricate carvings and velvet interior. Perfect for storing your precious accessories.',
    rating: 4.6,
    reviews: [
      {
        id: '3',
        userName: 'Anjali M.',
        rating: 5,
        comment: 'Beautiful craftsmanship! Love the intricate details.',
        date: '2024-01-20'
      }
    ],
    vendorStory: 'WoodCraft Collective is a family business that has been creating wooden masterpieces for three generations. They use only sustainable wood sources.'
  },
  {
    id: '3',
    name: 'Handwoven Textile Scarf',
    vendor: 'Threads of India',
    price: 549,
    image: 'https://images.unsplash.com/photo-1748141951488-9c9fb9603daf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZXh0aWxlJTIwZmFicmljJTIwaGFuZHdvdmVufGVufDF8fHx8MTc1ODc4NDE1M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Soft, handwoven scarf made from organic cotton with traditional patterns. A perfect accessory for any season.',
    rating: 4.7,
    reviews: [],
    vendorStory: 'Threads of India works directly with village weavers to preserve traditional textile arts while providing fair wages to artisans.'
  },
  {
    id: '4',
    name: 'Artisan Silver Earrings',
    vendor: 'Silver Stories',
    price: 799,
    image: 'https://images.unsplash.com/photo-1756792339453-bc4aa26fc0cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqZXdlbHJ5JTIwaGFuZG1hZGUlMjBhcnRpc2FufGVufDF8fHx8MTc1ODc4NDE1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    description: 'Elegant handcrafted silver earrings featuring traditional motifs. Each pair is unique and tells its own story.',
    rating: 4.9,
    reviews: [
      {
        id: '4',
        userName: 'Kavya R.',
        rating: 5,
        comment: 'Stunning earrings! Get compliments every time I wear them.',
        date: '2024-01-18'
      }
    ],
    vendorStory: 'Silver Stories is run by master craftsman Arjun Shah, who learned the art of silver jewelry making from his grandfather.'
  }
];

export const subscriptionBoxes: SubscriptionBox[] = [
  {
    id: 'basic',
    name: 'Starter Surprise',
    price: 250,
    description: 'Perfect for trying quirky finds',
    image: 'https://images.unsplash.com/photo-1608970800488-9d0f21f68132?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJwcmlzZSUyMG15c3RlcnklMjBib3glMjBnaWZ0fGVufDF8fHx8MTc1ODc4NDEzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: ['2-3 handpicked items', 'Monthly delivery', 'Surprise local finds', 'Free shipping']
  },
  {
    id: 'premium',
    name: 'Curated Collection',
    price: 500,
    description: 'For the avid quirky collector',
    image: 'https://images.unsplash.com/photo-1608970800488-9d0f21f68132?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJwcmlzZSUyMG15c3RlcnklMjBib3glMjBnaWZ0fGVufDF8fHx8MTc1ODc4NDEzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: ['4-5 premium items', 'Bi-weekly delivery', 'Exclusive artisan pieces', 'Free shipping', 'Priority support']
  },
  {
    id: 'deluxe',
    name: 'Artisan Treasure',
    price: 1000,
    description: 'Ultimate quirky experience',
    image: 'https://images.unsplash.com/photo-1608970800488-9d0f21f68132?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXJwcmlzZSUyMG15c3RlcnklMjBib3glMjBnaWZ0fGVufDF8fHx8MTc1ODc4NDEzOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    features: ['6-8 luxury items', 'Weekly delivery', 'Limited edition pieces', 'Free shipping', 'Personal curator', 'Exclusive events']
  }
];

export const mockOrders: Order[] = [
  {
    id: 'ORD001',
    date: '2024-01-15',
    total: 1500,
    status: 'Delivered',
    items: [
      {
        product: mockProducts[0],
        quantity: 1,
        isFavorite: true,
        userRating: 5,
        userReview: 'Love these bowls!'
      },
      {
        product: mockProducts[3],
        quantity: 1,
        isFavorite: false,
        userRating: 4
      }
    ]
  },
  {
    id: 'ORD002',
    date: '2024-01-10',
    total: 500,
    status: 'Subscription Box',
    items: [
      {
        product: mockProducts[1],
        quantity: 1,
        isFavorite: true
      },
      {
        product: mockProducts[2],
        quantity: 1,
        isFavorite: false,
        userRating: 5,
        userReview: 'Beautiful scarf, exactly as described!'
      }
    ]
  }
];
import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HomePage } from './components/HomePage';
import { SubscriptionsPage } from './components/SubscriptionsPage';
import { ProductDetailsPage } from './components/ProductDetailsPage';
import { OrderHistoryPage } from './components/OrderHistoryPage';
import { ProfilePage } from './components/ProfilePage';
import { FavouritesPage } from './components/FavouritesPage';
import { CartProvider } from './contexts/CartContext';
import { Toaster } from './components/ui/sonner';

type Page = 'home' | 'subscriptions' | 'product' | 'order-history' | 'profile' | 'favourites';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('');

  const handleNavigate = (page: string, productId?: string) => {
    setCurrentPage(page as Page);
    if (productId) {
      setSelectedProductId(productId);
    }
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onNavigate={handleNavigate} />;
      case 'subscriptions':
        return <SubscriptionsPage onNavigate={handleNavigate} />;
      case 'product':
        return <ProductDetailsPage productId={selectedProductId} />;
      case 'order-history':
        return <OrderHistoryPage onNavigate={handleNavigate} />;
      case 'profile':
        return <ProfilePage />;
      case 'favourites':
        return <FavouritesPage onNavigate={handleNavigate} />;
      default:
        return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <CartProvider>
      <div className="min-h-screen">
        <Navigation currentPage={currentPage} onNavigate={handleNavigate} />
        {renderCurrentPage()}
        <Toaster position="top-right" />
      </div>
    </CartProvider>
  );
}
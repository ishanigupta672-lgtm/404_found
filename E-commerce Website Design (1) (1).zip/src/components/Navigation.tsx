import { Search, ShoppingCart, Package, User, Heart, Clock, Settings } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { CartSidebar } from './CartSidebar';
import { useCart } from '../contexts/CartContext';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const { getTotalItems } = useCart();
  
  return (
    <nav className="bg-white shadow-sm border-b px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Brand Name */}
        <div 
          className="cursor-pointer"
          onClick={() => onNavigate('home')}
        >
          <h1 className="text-2xl font-bold" style={{ color: '#F4B400' }}>
            baazarbox
          </h1>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search for quirky finds..."
              className="pl-10 bg-gray-50 border-gray-200 rounded-full"
            />
          </div>
        </div>

        {/* Navigation Icons */}
        <div className="flex items-center space-x-4">
          {/* Cart */}
          <CartSidebar>
            <Button variant="ghost" size="icon" className="relative">
              <ShoppingCart className="h-6 w-6" />
              {getTotalItems() > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </Button>
          </CartSidebar>

          {/* Box Subscriptions */}
          <Button
            variant="ghost"
            className="flex items-center space-x-2"
            onClick={() => onNavigate('subscriptions')}
            style={{ 
              backgroundColor: currentPage === 'subscriptions' ? '#F4B400' : 'transparent',
              color: currentPage === 'subscriptions' ? 'white' : 'inherit'
            }}
          >
            <Package className="h-5 w-5" />
            <span>Box Subscriptions</span>
          </Button>

          {/* Profile Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <User className="h-6 w-6" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={() => onNavigate('profile')}>
                <User className="mr-2 h-4 w-4" />
                Profile
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onNavigate('order-history')}>
                <Clock className="mr-2 h-4 w-4" />
                Order History
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onNavigate('favourites')}>
                <Heart className="mr-2 h-4 w-4" />
                Favourites
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
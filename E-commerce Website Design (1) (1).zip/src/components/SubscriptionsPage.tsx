import { SubscriptionBoxCard } from './SubscriptionBoxCard';
import { ProductCard } from './ProductCard';
import { subscriptionBoxes, mockProducts } from '../data/mockData';

interface SubscriptionsPageProps {
  onNavigate: (page: string, productId?: string) => void;
}

export function SubscriptionsPage({ onNavigate }: SubscriptionsPageProps) {
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF9EA' }}>
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl text-gray-900 mb-4">
            Choose Your Surprise Box Subscription
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get a curated collection of unique, handcrafted items delivered to your doorstep every month. 
            Each box is a delightful surprise filled with local artisan treasures.
          </p>
        </div>

        {/* Subscription Options */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {subscriptionBoxes.map((box, index) => (
            <SubscriptionBoxCard
              key={box.id}
              box={box}
              featured={index === 1} // Make the middle option featured
            />
          ))}
        </div>
      </section>

      {/* Explore More Items Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h2 className="text-3xl text-gray-900 mb-2">Explore More Items</h2>
          <p className="text-gray-600">Individual pieces you can purchase separately</p>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-4">
          {mockProducts.map((product) => (
            <ProductCard
              key={`sub-${product.id}`}
              product={product}
              onProductClick={(productId) => onNavigate('product', productId)}
            />
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="bg-white rounded-lg shadow-lg p-12">
          <h2 className="text-3xl text-gray-900 text-center mb-8">Why Choose baazarbox?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                style={{ backgroundColor: '#34A853' }}
              >
                <span className="text-white text-2xl">🎨</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Handpicked Items</h3>
              <p className="text-gray-600">Every item is carefully selected from local artisans who pour their heart into their craft.</p>
            </div>
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                style={{ backgroundColor: '#4285F4' }}
              >
                <span className="text-white text-2xl">📦</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Monthly Surprises</h3>
              <p className="text-gray-600">Experience the joy of unboxing something new and unexpected every month.</p>
            </div>
            <div className="text-center">
              <div 
                className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                style={{ backgroundColor: '#EA4335' }}
              >
                <span className="text-white text-2xl">❤️</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Support Local</h3>
              <p className="text-gray-600">Your subscription directly supports local artisans and helps preserve traditional crafts.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
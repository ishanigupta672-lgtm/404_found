import { Heart, ShoppingCart, Star } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockOrders } from '../data/mockData';
import { useCart } from '../contexts/CartContext';

interface FavouritesPageProps {
  onNavigate: (page: string, productId?: string) => void;
}

export function FavouritesPage({ onNavigate }: FavouritesPageProps) {
  const { addToCart } = useCart();

  // Extract all favorited items from orders
  const favouriteItems = mockOrders
    .flatMap(order => order.items)
    .filter(item => item.isFavorite)
    .reduce((unique, item) => {
      // Remove duplicates based on product id
      if (!unique.find(u => u.product.id === item.product.id)) {
        unique.push(item);
      }
      return unique;
    }, [] as typeof mockOrders[0]['items']);

  const handleAddToCart = (productId: string, productName: string) => {
    addToCart(productId, 1);
  };

  const handleViewProduct = (productId: string) => {
    onNavigate('product', productId);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF9EA' }}>
      <div className="max-w-6xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-4xl text-gray-900 mb-2">My Favourites</h1>
          <p className="text-xl text-gray-600">
            Your curated collection of loved items
          </p>
        </div>

        {favouriteItems.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {favouriteItems.map((item, index) => (
              <Card key={`${item.product.id}-${index}`} className="bg-white shadow-md hover:shadow-lg transition-shadow duration-200">
                <CardHeader className="p-0">
                  <div 
                    className="w-full h-48 bg-gray-100 rounded-t-lg overflow-hidden cursor-pointer"
                    onClick={() => handleViewProduct(item.product.id)}
                  >
                    <ImageWithFallback
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                    />
                  </div>
                </CardHeader>
                
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-2">
                    <h3 
                      className="font-semibold text-gray-900 line-clamp-2 cursor-pointer hover:text-blue-600 transition-colors"
                      onClick={() => handleViewProduct(item.product.id)}
                    >
                      {item.product.name}
                    </h3>
                    <Heart className="h-5 w-5 text-red-500 fill-current flex-shrink-0 ml-2" />
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-2">by {item.product.vendor}</p>
                  
                  <div className="flex items-center space-x-1 mb-3">
                    {renderStars(item.product.rating)}
                    <span className="text-sm text-gray-600 ml-1">
                      ({item.product.rating})
                    </span>
                  </div>
                  
                  <div className="mb-4">
                    <p className="text-sm text-gray-700 line-clamp-2">
                      {item.product.vendorStory}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-semibold text-gray-900">
                      ₹{item.product.price}
                    </span>
                    
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleViewProduct(item.product.id)}
                        className="text-sm"
                      >
                        View Details
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleAddToCart(item.product.id, item.product.name)}
                        className="text-sm"
                        style={{ backgroundColor: '#F4B400', color: 'white' }}
                      >
                        <ShoppingCart className="h-4 w-4 mr-1" />
                        Add to Cart
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="bg-white rounded-lg shadow-md p-12">
              <Heart className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-2xl text-gray-900 mb-4">No favourites yet</h3>
              <p className="text-gray-600 mb-8">
                Start exploring our quirky finds and add items to your favourites!
              </p>
              <Button
                size="lg"
                onClick={() => onNavigate('home')}
                style={{ backgroundColor: '#F4B400', color: 'white' }}
              >
                Start Shopping
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
import { Check } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { SubscriptionBox } from '../data/mockData';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner@2.0.3';

interface SubscriptionBoxCardProps {
  box: SubscriptionBox;
  featured?: boolean;
}

export function SubscriptionBoxCard({ box, featured = false }: SubscriptionBoxCardProps) {
  const { addToCart } = useCart();

  const handleSubscribe = () => {
    addToCart({
      id: `subscription-${box.id}`,
      name: `${box.name} Subscription`,
      price: box.price,
      image: box.image,
      type: 'subscription'
    });
    toast.success(`${box.name} subscription added to cart!`);
  };

  return (
    <Card 
      className={`relative overflow-hidden shadow-lg hover:shadow-xl transition-shadow ${
        featured ? 'ring-2 ring-yellow-400 scale-105' : ''
      }`}
      style={{ backgroundColor: '#FFFFFF' }}
    >
      {featured && (
        <div 
          className="absolute top-0 right-0 px-3 py-1 text-white text-sm font-medium"
          style={{ backgroundColor: '#F4B400' }}
        >
          Most Popular
        </div>
      )}
      
      <div className="aspect-video relative">
        <ImageWithFallback
          src={box.image}
          alt={box.name}
          className="w-full h-full object-cover"
        />
      </div>

      <CardHeader className="text-center pb-4">
        <h3 className="text-2xl font-bold text-gray-900">{box.name}</h3>
        <p className="text-gray-600">{box.description}</p>
        <div className="text-4xl font-bold mt-2" style={{ color: '#F4B400' }}>
          ₹{box.price}
          <span className="text-sm text-gray-500 font-normal">/month</span>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <ul className="space-y-3">
          {box.features.map((feature, index) => (
            <li key={index} className="flex items-center space-x-3">
              <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>

        <div className="space-y-3">
          <Button
            className="w-full py-3 text-lg"
            style={{ backgroundColor: '#F4B400', color: 'white' }}
            onClick={handleSubscribe}
          >
            Subscribe Now
          </Button>
          <Button
            variant="outline"
            className="w-full py-3 text-lg"
          >
            Learn More
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
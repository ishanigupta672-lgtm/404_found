import { useState } from 'react';
import { Star, Heart, ShoppingCart } from 'lucide-react';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockProducts, Product } from '../data/mockData';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner@2.0.3';

interface ProductDetailsPageProps {
  productId: string;
}

export function ProductDetailsPage({ productId }: ProductDetailsPageProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToCart } = useCart();
  const product = mockProducts.find(p => p.id === productId);

  const handleAddToCart = () => {
    if (product) {
      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        type: 'product'
      });
      toast.success(`${product.name} added to cart!`);
    }
  };

  const handleBuyNow = () => {
    if (product) {
      addToCart({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        type: 'product'
      });
      toast.success(`${product.name} added to cart! Redirecting to checkout...`);
      // Here you would typically redirect to checkout
    }
  };

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ backgroundColor: '#FFF9EA' }}>
        <div className="text-center">
          <h2 className="text-2xl text-gray-900 mb-4">Product not found</h2>
          <p className="text-gray-600">The product you're looking for doesn't exist.</p>
        </div>
      </div>
    );
  }

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-5 w-5 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF9EA' }}>
      <div className="max-w-7xl mx-auto px-6 py-12">
        {/* Product Details Section */}
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Product Image */}
          <div className="aspect-square bg-white rounded-lg shadow-lg overflow-hidden">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-4xl text-gray-900 mb-2">{product.name}</h1>
              <p className="text-xl text-gray-600">by {product.vendor}</p>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                {renderStars(product.rating)}
                <span className="text-gray-600 ml-2">({product.rating}/5)</span>
              </div>
              <span className="text-gray-400">•</span>
              <span className="text-gray-600">{product.reviews.length} reviews</span>
            </div>

            <div className="text-4xl font-bold" style={{ color: '#F4B400' }}>
              ₹{product.price}
            </div>

            <p className="text-lg text-gray-700 leading-relaxed">
              {product.description}
            </p>

            <div className="flex space-x-4">
              <Button
                size="lg"
                className="flex-1 py-4 text-lg"
                style={{ backgroundColor: '#F4B400', color: 'white' }}
                onClick={handleAddToCart}
              >
                <ShoppingCart className="mr-2 h-5 w-5" />
                Add to Cart
              </Button>
              <Button
                size="lg"
                className="flex-1 py-4 text-lg"
                style={{ backgroundColor: '#EA4335', color: 'white' }}
                onClick={handleBuyNow}
              >
                Buy Now
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setIsFavorite(!isFavorite)}
                className="px-6"
              >
                <Heart className={`h-5 w-5 ${isFavorite ? 'text-red-500 fill-current' : ''}`} />
              </Button>
            </div>
          </div>
        </div>

        {/* Tabs Section */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          <Tabs defaultValue="reviews" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="reviews">Reviews & Ratings</TabsTrigger>
              <TabsTrigger value="vendor">Vendor Story</TabsTrigger>
            </TabsList>

            <TabsContent value="reviews" className="space-y-8 mt-8">
              {/* Reviews Summary */}
              <div className="flex items-center space-x-8 pb-6 border-b">
                <div className="text-center">
                  <div className="text-4xl font-bold mb-2">{product.rating}</div>
                  <div className="flex items-center justify-center space-x-1 mb-2">
                    {renderStars(product.rating)}
                  </div>
                  <div className="text-sm text-gray-600">{product.reviews.length} reviews</div>
                </div>
                <div className="flex-1">
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map((stars) => {
                      const count = product.reviews.filter(r => Math.floor(r.rating) === stars).length;
                      const percentage = product.reviews.length > 0 ? (count / product.reviews.length) * 100 : 0;
                      return (
                        <div key={stars} className="flex items-center space-x-2">
                          <span className="text-sm w-8">{stars}★</span>
                          <div className="flex-1 bg-gray-200 rounded-full h-2">
                            <div
                              className="h-2 rounded-full"
                              style={{ 
                                backgroundColor: '#F4B400',
                                width: `${percentage}%`
                              }}
                            />
                          </div>
                          <span className="text-sm text-gray-600 w-8">{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Individual Reviews */}
              <div className="space-y-6">
                {product.reviews.length > 0 ? (
                  product.reviews.map((review) => (
                    <div key={review.id} className="border-b pb-6 last:border-b-0">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{review.userName}</span>
                        <span className="text-sm text-gray-500">{review.date}</span>
                      </div>
                      <div className="flex items-center space-x-1 mb-2">
                        {renderStars(review.rating)}
                      </div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-600">No reviews yet. Be the first to review this product!</p>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="vendor" className="mt-8">
              <div className="space-y-6">
                <div>
                  <h3 className="text-2xl font-semibold mb-4">About {product.vendor}</h3>
                  <p className="text-lg text-gray-700 leading-relaxed">
                    {product.vendorStory}
                  </p>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold mb-3">Vendor Details</h4>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Store Name:</span> {product.vendor}</p>
                    <p><span className="font-medium">Speciality:</span> Handcrafted goods</p>
                    <p><span className="font-medium">Location:</span> India</p>
                    <p><span className="font-medium">Member Since:</span> 2018</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { ChevronDown, ChevronUp, Star, Heart, ShoppingCart } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Textarea } from './ui/textarea';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockOrders, OrderItem } from '../data/mockData';

interface OrderHistoryPageProps {
  onNavigate?: (page: string, productId?: string) => void;
}

export function OrderHistoryPage({ onNavigate }: OrderHistoryPageProps) {
  const [expandedOrders, setExpandedOrders] = useState<string[]>([]);
  const [itemRatings, setItemRatings] = useState<{[key: string]: number}>({});
  const [itemReviews, setItemReviews] = useState<{[key: string]: string}>({});
  const [favorites, setFavorites] = useState<{[key: string]: boolean}>({});

  const toggleOrderExpanded = (orderId: string) => {
    setExpandedOrders(prev => 
      prev.includes(orderId) 
        ? prev.filter(id => id !== orderId)
        : [...prev, orderId]
    );
  };

  const handleRatingChange = (itemKey: string, rating: number) => {
    setItemRatings(prev => ({ ...prev, [itemKey]: rating }));
  };

  const handleReviewChange = (itemKey: string, review: string) => {
    setItemReviews(prev => ({ ...prev, [itemKey]: review }));
  };

  const toggleFavorite = (itemKey: string) => {
    setFavorites(prev => ({ ...prev, [itemKey]: !prev[itemKey] }));
  };

  const renderStars = (rating: number, itemKey: string, interactive: boolean = false) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-5 w-5 cursor-pointer ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
        onClick={interactive ? () => handleRatingChange(itemKey, i + 1) : undefined}
      />
    ));
  };

  const handleViewProduct = (productId: string) => {
    if (onNavigate) {
      onNavigate('product', productId);
    }
  };

  const renderOrderItem = (item: OrderItem, orderId: string, index: number) => {
    const itemKey = `${orderId}-${index}`;
    const currentRating = itemRatings[itemKey] || item.userRating || 0;
    const currentReview = itemReviews[itemKey] || item.userReview || '';
    const isFavorite = favorites[itemKey] || item.isFavorite;

    return (
      <div key={itemKey} className="bg-gray-50 rounded-lg p-4 space-y-4">
        <div className="flex items-start space-x-4">
          <div 
            className="w-20 h-20 bg-white rounded-lg overflow-hidden flex-shrink-0 cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => handleViewProduct(item.product.id)}
          >
            <ImageWithFallback
              src={item.product.image}
              alt={item.product.name}
              className="w-full h-full object-cover hover:scale-105 transition-transform"
            />
          </div>
          <div className="flex-1 min-w-0">
            <h4 
              className="font-medium text-gray-900 truncate cursor-pointer hover:text-blue-600 transition-colors"
              onClick={() => handleViewProduct(item.product.id)}
            >
              {item.product.name}
            </h4>
            <p className="text-sm text-gray-600">by {item.product.vendor}</p>
            <p className="text-lg font-semibold mt-1">₹{item.product.price}</p>
            {item.quantity > 1 && (
              <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
            )}
          </div>
          <div className="flex flex-col space-y-2 flex-shrink-0">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => toggleFavorite(itemKey)}
            >
              <Heart className={`h-5 w-5 ${isFavorite ? 'text-red-500 fill-current' : 'text-gray-400'}`} />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleViewProduct(item.product.id)}
              className="text-xs"
            >
              <ShoppingCart className="h-4 w-4 mr-1" />
              Buy Again
            </Button>
          </div>
        </div>

        {/* Vendor Story Section */}
        <div className="bg-white rounded-md p-3 border-l-4 border-blue-200">
          <h5 className="text-sm font-medium text-gray-700 mb-1">Vendor Story</h5>
          <p className="text-sm text-gray-600 leading-relaxed">
            {item.product.vendorStory}
          </p>
        </div>

        {/* Rating Section */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Rate this item:</label>
          <div className="flex items-center space-x-1">
            {renderStars(currentRating, itemKey, true)}
            {currentRating > 0 && (
              <span className="text-sm text-gray-600 ml-2">({currentRating}/5)</span>
            )}
          </div>
        </div>

        {/* Review Section */}
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700">Write a review:</label>
          <Textarea
            value={currentReview}
            onChange={(e) => handleReviewChange(itemKey, e.target.value)}
            placeholder="Share your thoughts about this item..."
            className="min-h-[80px]"
          />
          {currentReview !== (item.userReview || '') && (
            <Button 
              size="sm" 
              className="w-fit"
              style={{ backgroundColor: '#F4B400', color: 'white' }}
            >
              Save Review
            </Button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF9EA' }}>
      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h1 className="text-4xl text-gray-900 mb-2">Order History</h1>
          <p className="text-xl text-gray-600">Track your orders and share your experience</p>
        </div>

        <div className="space-y-6">
          {mockOrders.map((order) => {
            const isExpanded = expandedOrders.includes(order.id);
            
            return (
              <Card key={order.id} className="bg-white shadow-md">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">Order #{order.id}</h3>
                      <p className="text-sm text-gray-600">
                        {order.date} • {order.items.length} item{order.items.length > 1 ? 's' : ''} • ₹{order.total}
                      </p>
                    </div>
                    <div className="flex items-center space-x-4">
                      <span 
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          order.status === 'Delivered' 
                            ? 'bg-green-100 text-green-800'
                            : order.status === 'Subscription Box'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {order.status}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleOrderExpanded(order.id)}
                      >
                        {isExpanded ? (
                          <ChevronUp className="h-4 w-4" />
                        ) : (
                          <ChevronDown className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {isExpanded && (
                  <CardContent className="pt-0">
                    <div className="space-y-4">
                      <div className="border-t pt-4">
                        <h4 className="font-medium text-gray-900 mb-4">Items in this order:</h4>
                        <div className="space-y-4">
                          {order.items.map((item, index) => renderOrderItem(item, order.id, index))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            );
          })}
        </div>

        {mockOrders.length === 0 && (
          <div className="text-center py-16">
            <div className="bg-white rounded-lg shadow-md p-12">
              <h3 className="text-2xl text-gray-900 mb-4">No orders yet</h3>
              <p className="text-gray-600 mb-8">
                Start exploring our quirky finds and place your first order!
              </p>
              <Button
                size="lg"
                style={{ backgroundColor: '#F4B400', color: 'white' }}
              >
                Start Shopping
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useCart } from '../contexts/CartContext';
import { toast } from 'sonner@2.0.3';

interface Product {
  id: string;
  name: string;
  vendor: string;
  price: number;
  image: string;
}

interface ProductCardProps {
  product: Product;
  onProductClick: (productId: string) => void;
}

export function ProductCard({ product, onProductClick }: ProductCardProps) {
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      type: 'product'
    });
    toast.success(`${product.name} added to cart!`);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      type: 'product'
    });
    toast.success(`${product.name} added to cart! Redirecting to checkout...`);
    // Here you would typically redirect to checkout
  };

  return (
    <Card 
      className="w-64 flex-shrink-0 shadow-md hover:shadow-lg transition-shadow cursor-pointer bg-white rounded-lg overflow-hidden"
      onClick={() => onProductClick(product.id)}
    >
      <CardContent className="p-0">
        <div className="aspect-square relative">
          <ImageWithFallback
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="p-4">
          <h3 className="font-medium text-gray-900 mb-1 line-clamp-2">{product.name}</h3>
          <p className="text-sm text-gray-600 mb-2">by {product.vendor}</p>
          <div className="flex items-center justify-between">
            <span className="font-bold text-lg">₹{product.price}</span>
            <div className="flex space-x-2">
              <Button 
                size="sm" 
                variant="outline"
                className="text-xs px-3"
                onClick={handleAddToCart}
              >
                Add to Cart
              </Button>
              <Button 
                size="sm"
                className="text-xs px-3"
                style={{ backgroundColor: '#F4B400', color: 'white' }}
                onClick={handleBuyNow}
              >
                Buy Now
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
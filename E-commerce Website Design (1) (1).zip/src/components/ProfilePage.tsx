import { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { User, Mail, Phone, MapPin, Calendar, Heart, Gift, CreditCard } from 'lucide-react';

export function ProfilePage() {
  const [userInfo, setUserInfo] = useState({
    name: 'Priya Sharma',
    email: 'priya.sharma@email.com',
    phone: '+91 98765 43210',
    address: '123 MG Road, Bangalore, Karnataka 560001',
    joinDate: 'March 2023'
  });

  const [isEditing, setIsEditing] = useState(false);

  const favoriteItems = [
    { id: '1', name: 'Handwoven Bamboo Basket', image: 'https://images.unsplash.com/photo-1586951823942-4c7a0c9e9976?w=150&h=150&fit=crop', price: 890 },
    { id: '2', name: 'Ceramic Tea Cup Set', image: 'https://images.unsplash.com/photo-1594736797933-d0401ba2fe65?w=150&h=150&fit=crop', price: 1250 },
    { id: '3', name: 'Block Print Cushion Cover', image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=150&h=150&fit=crop', price: 650 }
  ];

  const subscriptionHistory = [
    { id: '1', plan: 'Premium Box', price: 1000, status: 'Active', nextDelivery: '15 Jan 2024' },
    { id: '2', plan: 'Classic Box', price: 500, status: 'Paused', nextDelivery: '-' },
    { id: '3', plan: 'Starter Box', price: 250, status: 'Completed', nextDelivery: '-' }
  ];

  const handleSave = () => {
    setIsEditing(false);
    // Here you would typically save to backend
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF9EA' }}>
      <div className="max-w-6xl mx-auto px-6 py-8">
        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card className="bg-white shadow-lg rounded-lg">
              <CardHeader className="flex flex-row items-center space-y-0 pb-6">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src="https://images.unsplash.com/photo-1494790108755-2616b9a77ded?w=150&h=150&fit=crop" />
                    <AvatarFallback style={{ backgroundColor: '#F4B400', color: 'white' }}>PS</AvatarFallback>
                  </Avatar>
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">{userInfo.name}</h1>
                    <p className="text-gray-600">baazarbox Member since {userInfo.joinDate}</p>
                    <Badge style={{ backgroundColor: '#34A853', color: 'white' }} className="mt-2">
                      Premium Member
                    </Badge>
                  </div>
                </div>
                <div className="ml-auto">
                  <Button
                    onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                    style={{ backgroundColor: '#F4B400', color: 'white' }}
                  >
                    {isEditing ? 'Save Changes' : 'Edit Profile'}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <User className="h-5 w-5 text-gray-400" />
                      <div className="flex-1">
                        <Label htmlFor="name">Full Name</Label>
                        {isEditing ? (
                          <Input
                            id="name"
                            value={userInfo.name}
                            onChange={(e) => setUserInfo(prev => ({ ...prev, name: e.target.value }))}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{userInfo.name}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <Mail className="h-5 w-5 text-gray-400" />
                      <div className="flex-1">
                        <Label htmlFor="email">Email</Label>
                        {isEditing ? (
                          <Input
                            id="email"
                            type="email"
                            value={userInfo.email}
                            onChange={(e) => setUserInfo(prev => ({ ...prev, email: e.target.value }))}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{userInfo.email}</p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Phone className="h-5 w-5 text-gray-400" />
                      <div className="flex-1">
                        <Label htmlFor="phone">Phone</Label>
                        {isEditing ? (
                          <Input
                            id="phone"
                            value={userInfo.phone}
                            onChange={(e) => setUserInfo(prev => ({ ...prev, phone: e.target.value }))}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{userInfo.phone}</p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <MapPin className="h-5 w-5 text-gray-400" />
                      <div className="flex-1">
                        <Label htmlFor="address">Address</Label>
                        {isEditing ? (
                          <Input
                            id="address"
                            value={userInfo.address}
                            onChange={(e) => setUserInfo(prev => ({ ...prev, address: e.target.value }))}
                            className="mt-1"
                          />
                        ) : (
                          <p className="text-gray-900">{userInfo.address}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="grid md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <Gift className="h-8 w-8 mx-auto mb-2 text-orange-500" />
                    <p className="text-2xl font-bold text-gray-900">12</p>
                    <p className="text-gray-600">Boxes Received</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <Heart className="h-8 w-8 mx-auto mb-2 text-red-500" />
                    <p className="text-2xl font-bold text-gray-900">8</p>
                    <p className="text-gray-600">Favorite Items</p>
                  </div>
                  <div className="text-center p-4 bg-gray-50 rounded-lg">
                    <Calendar className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                    <p className="text-2xl font-bold text-gray-900">9</p>
                    <p className="text-gray-600">Months Active</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="favorites" className="space-y-6">
            <Card className="bg-white shadow-lg rounded-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Heart className="h-6 w-6 text-red-500" />
                  <span>Favorite Items</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-6">
                  {favoriteItems.map((item) => (
                    <div key={item.id} className="bg-gray-50 rounded-lg p-4">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                      <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                      <p className="text-gray-600">₹{item.price}</p>
                      <Button
                        size="sm"
                        className="w-full mt-3"
                        style={{ backgroundColor: '#F4B400', color: 'white' }}
                      >
                        Add to Cart
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="subscriptions" className="space-y-6">
            <Card className="bg-white shadow-lg rounded-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Gift className="h-6 w-6 text-orange-500" />
                  <span>Subscription History</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {subscriptionHistory.map((sub) => (
                    <div key={sub.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h3 className="font-semibold text-gray-900">{sub.plan}</h3>
                        <p className="text-gray-600">₹{sub.price}/month</p>
                      </div>
                      <div className="text-right">
                        <Badge
                          variant={sub.status === 'Active' ? 'default' : sub.status === 'Paused' ? 'secondary' : 'outline'}
                          style={sub.status === 'Active' ? { backgroundColor: '#34A853', color: 'white' } : {}}
                        >
                          {sub.status}
                        </Badge>
                        <p className="text-sm text-gray-600 mt-1">Next: {sub.nextDelivery}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-white shadow-lg rounded-lg">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-6 w-6 text-blue-500" />
                  <span>Account Settings</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Notification Preferences</h3>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span>Email notifications</span>
                      <Button variant="outline" size="sm">Enabled</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>SMS notifications</span>
                      <Button variant="outline" size="sm">Disabled</Button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Marketing emails</span>
                      <Button variant="outline" size="sm">Enabled</Button>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Privacy Settings</h3>
                  <div className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      Change Password
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      Download My Data
                    </Button>
                    <Button variant="destructive" className="w-full justify-start">
                      Delete Account
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
import { Button } from './ui/button';
import { ProductCard } from './ProductCard';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { mockProducts } from '../data/mockData';

interface HomePageProps {
  onNavigate: (page: string, productId?: string) => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const bestsellers = mockProducts.slice(0, 4);
  const exploreItems = mockProducts;

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFF9EA' }}>
      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-5xl leading-tight text-gray-900">
              Discover Quirky Finds from Local Makers
            </h1>
            <p className="text-xl text-gray-600 leading-relaxed">
              Unbox the unexpected with handcrafted treasures from talented artisans across India. Every item tells a story, every box brings joy.
            </p>
            <Button
              size="lg"
              className="px-8 py-4 text-lg"
              style={{ backgroundColor: '#F4B400', color: 'white' }}
              onClick={() => onNavigate('subscriptions')}
            >
              Explore Surprise Boxes
            </Button>
          </div>
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1607940471713-a9376f150a0d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicm93biUyMGNhcmRib2FyZCUyMGJveCUyMHN1cnByaXNlJTIwZ2lmdHxlbnwxfHx8fDE3NTg3ODQ3NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Brown Surprise Box"
              className="w-full h-96 object-cover rounded-lg shadow-lg"
            />
          </div>
        </div>
      </section>

      {/* Bestsellers Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h2 className="text-3xl text-gray-900 mb-2">Bestsellers</h2>
          <p className="text-gray-600">Our most loved items from local artisans</p>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-4">
          {bestsellers.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onProductClick={(productId) => onNavigate('product', productId)}
            />
          ))}
        </div>
      </section>

      {/* Explore More Items Section */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-8">
          <h2 className="text-3xl text-gray-900 mb-2">Explore More Items</h2>
          <p className="text-gray-600">Discover unique finds from talented makers</p>
        </div>
        <div className="flex gap-6 overflow-x-auto pb-4">
          {exploreItems.map((product) => (
            <ProductCard
              key={`explore-${product.id}`}
              product={product}
              onProductClick={(productId) => onNavigate('product', productId)}
            />
          ))}
        </div>
      </section>

      {/* Call to Action */}
      <section className="max-w-7xl mx-auto px-6 py-16 text-center">
        <div className="bg-white rounded-lg shadow-lg p-12">
          <h2 className="text-3xl text-gray-900 mb-4">Ready for Your First Surprise?</h2>
          <p className="text-xl text-gray-600 mb-8">
            Join thousands of happy customers who get their monthly dose of quirky finds
          </p>
          <Button
            size="lg"
            className="px-8 py-4 text-lg"
            style={{ backgroundColor: '#EA4335', color: 'white' }}
            onClick={() => onNavigate('subscriptions')}
          >
            Start Your Subscription
          </Button>
        </div>
      </section>
    </div>
  );
}